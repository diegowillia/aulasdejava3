/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projetodiego;

/**
 *
 * @author diego.wsilva5
 */
public class ProjetoDiego {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
